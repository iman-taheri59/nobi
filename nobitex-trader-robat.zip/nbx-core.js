/* ============================================================
 * Nobitex Trader Bot — Core (Phase 1, Real Components)
 * Implements per ADRs: 0003 API client, 0004 data store,
 * 0005 TA engine, 0007 decision scoring
 * Exposes window.NBX with namespaces for app consumption.
 * ============================================================ */
(function () {
  'use strict';

  window.NBX = window.NBX || {};

  /* ----------------------------------------------------------
   * 0. Config
   * --------------------------------------------------------- */
  const self = (typeof window !== 'undefined' ? window : {});
  const cfg = Object.assign(
    {
      baseUrl: 'https://apiv2.nobitex.ir',
      apiProxy: '', // e.g. 'https://corsproxy.io/?' or own FastAPI /proxy?url=
      pythonApi: 'http://localhost:8000/api', // Phase 1: local FastAPI backend
      preferPython: true,
      timeoutMs: 9000,
      maxRetries: 3,
      ratePerMinute: 120,
      userAgentNote: 'TraderBot/1.0 research-web-client',
      timeframes: ['15m', '1h', '4h', 'D'],
      universeTopN: 40,
      maxCandles: 260,
      // seed symbols if stats fetch fails (IRT + USDT legs)
      seedSymbols: [
        'BTCIRT', 'ETHIRT', 'TONIRT', 'TRXIRT', 'DOGEIRT', 'ADAIRT', 'LTCIRT', 'XRPUSDT',
        'ETHUSDT', 'SOLUSDT', 'TONUSDT', 'TRXUSDT', 'DOGEUSDT', 'ADAUSDT', 'BTCUSDT', 'USDTIRT'
      ],
    },
    self.__NBX_CONFIG || {}
  );
  NBX.config = cfg;

  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const nowMs = () => Date.now();
  const normSymbol = (s) => (s || '').toUpperCase().replace(/\s+/g, '');
  const isIRTSymbol = (s) => normSymbol(s).endsWith('IRT');
  const isUSDTSymbol = (s) => normSymbol(s).endsWith('USDT') || normSymbol(s).endsWith('USD');

  const NBXError = class extends Error {
    constructor(code, message, meta) {
      super(message);
      this.name = 'NBXError';
      this.code = code; // 'NETWORK' | 'HTTP' | 'RATE' | 'DATA' | 'AUTH'
      this.meta = meta || {};
    }
  };
  NBX.errors = { NBXError };

  /* ----------------------------------------------------------
   * 1. Token bucket
   * --------------------------------------------------------- */
  NBX.TokenBucket = class {
    constructor(perMin) {
      this.capacity = perMin;
      this.tokens = perMin;
      this.refillPerMs = perMin / 60000;
      this.lastTake = nowMs();
    }
    _refill() {
      const now = nowMs();
      const mins = (now - this.lastTake) * this.refillPerMs;
      this.tokens = Math.min(this.capacity, this.tokens + mins);
      this.lastTake = now;
    }
    allow(cost = 1) {
      this._refill();
      if (this.tokens >= cost) {
        this.tokens -= cost;
        return true;
      }
      return false;
    }
  };

  /* ----------------------------------------------------------
   * 2. API client (browser-safe, with graceful fallback)
   * --------------------------------------------------------- */
  class NobitexApi {
    constructor(options) {
      this.opts = Object.assign({}, cfg, options || {});
      this.bucket = new NBX.TokenBucket(this.opts.ratePerMinute);
      this.connected = false;
      this.corsOk = null; // null unknown, true direct/CORS ok, false fallback
      this.stats = { total: 0, ok: 0, fail: 0, lastLatencyMs: null };
      this._healthListeners = [];
    }

    _url(path) {
      return this.opts.baseUrl + path;
    }

    onHealth(fn) {
      this._healthListeners.push(fn);
      return () => (this._healthListeners = this._healthListeners.filter((x) => x !== fn));
    }
    _emitHealth(h) {
      this.connected = h.ok;
      this._healthListeners.forEach((fn) => { try { fn(h); } catch (e) {} });
    }

    async _fetch(path) {
      const url = this._url(path);
      const proxy = this.opts.apiProxy || '';
      const finalUrl = proxy ? proxy + encodeURIComponent(url) : url;
      const t0 = performance.now();
      const controller = new AbortController();
      const to = setTimeout(() => controller.abort(), this.opts.timeoutMs);
      try {
        const res = await fetch(finalUrl, { signal: controller.signal, mode: proxy ? 'cors' : 'cors' });
        clearTimeout(to);
        const latency = performance.now() - t0;
        this.stats.total++;
        this.stats.lastLatencyMs = latency;
        if (!res.ok) {
          this.stats.fail++;
          if (res.status === 429) throw new NBXError('RATE', 'rate limited', { status: res.status });
          throw new NBXError('HTTP', 'bad status ' + res.status, { status: res.status });
        }
        const data = await res.json();
        this.stats.ok++;
        this._emitHealth({ ok: true, latency });
        return data;
      } catch (e) {
        clearTimeout(to);
        this.stats.fail++;
        this._emitHealth({ ok: false, error: e });
        if (e instanceof NBXError) throw e;
        throw new NBXError('NETWORK', e.message || 'fetch failed', { error: e });
      }
    }

    async get(path, attempts) {
      let tries = attempts !== undefined ? attempts : this.opts.maxRetries;
      let lastErr;
      for (let i = 0; i < tries; i++) {
        if (this.bucket.tokens < 1) await sleep(1200 / this.opts.ratePerMinute + 40);
        try {
          if (!this.bucket.allow()) await sleep(250);
          return await this._fetch(path);
        } catch (e) {
          lastErr = e;
          if (e.code === 'RATE') await sleep(1500 * (i + 1));
          else if (e.name === 'AbortError' || e.code === 'NETWORK') await sleep(400 * (i + 1) + Math.random() * 200);
          else break;
        }
      }
      throw lastErr;
    }

    async healthCheck() {
      try {
        const r = await this.get('/v3/orderbook/BTCIRT', 1);
        return { ok: !!(r && r.status === 'ok'), latency: this.stats.lastLatencyMs };
      } catch (e) {
        return { ok: false, error: e.code };
      }
    }

    /* When the Python backend is up, use its consolidated endpoints */
    async checkBackend() {
      if (!cfg.preferPython) return null;
      try {
        const r = await this.get(cfg.pythonApi.replace('/api', '') + '/api/health', 1);
        return r && r.backend ? r : null;
      } catch (e) {
        return null;
      }
    }

    async getBackendSignals(tf) {
      const r = await this.get(cfg.pythonApi + '/signals?tf=' + encodeURIComponent(tf), 1);
      if (r && r.scored) return r;
      throw new NBXError('DATA', 'bad backend signals');
    }

    async getBackendUniverse() {
      const r = await this.get(cfg.pythonApi + '/universe', 1);
      if (r && Array.isArray(r.symbols)) return r;
      throw new NBXError('DATA', 'bad backend universe');
    }

    async getBackendCandles(symbol, tf) {
      const r = await this.get(cfg.pythonApi + '/candles/' + encodeURIComponent(symbol) + '?tf=' + encodeURIComponent(tf), 1);
      if (r && Array.isArray(r.rows)) return r;
      throw new NBXError('DATA', 'bad backend candles');
    }

    async getBackendFA(symbol) {
      const r = await this.get(cfg.pythonApi + '/fa/' + encodeURIComponent(symbol), 1);
      if (r && typeof r.score === 'number') return r;
      throw new NBXError('DATA', 'bad backend fa');
    }

    async getBackendRiskState() {
      const r = await this.get(cfg.pythonApi + '/risk/state', 1);
      if (r && r.equity !== undefined) return r;
      throw new NBXError('DATA', 'bad backend risk state');
    }

    async getBackendRiskPlan(symbol, side) {
      const r = await this.get(cfg.pythonApi + '/risk/plan?symbol=' + encodeURIComponent(symbol) + '&side=' + encodeURIComponent(side || 'buy'), 1);
      if (r && r.action) return r;
      throw new NBXError('DATA', 'bad backend risk plan');
    }

    async postPaperOrder(payload) {
      const res = await fetch(cfg.pythonApi + '/paper/order', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const r = await res.json();
      if (res.ok && r && r.ok !== undefined) return r;
      throw new NBXError('HTTP', 'paper order failed', { status: res.status, r });
    }

    async getPaperPositions() {
      const r = await this.get(cfg.pythonApi + '/paper/positions', 1);
      if (r && Array.isArray(r.positions)) return r;
      throw new NBXError('DATA', 'bad paper positions');
    }

    async getPaperMetrics() {
      const r = await this.get(cfg.pythonApi + '/paper/metrics', 1);
      if (r && r.metrics) return r;
      throw new NBXError('DATA', 'bad paper metrics');
    }

    async getWsStatus() {
      const r = await this.get(cfg.pythonApi + '/ws/status', 1);
      if (r && r.books) return r;
      throw new NBXError('DATA', 'bad ws status');
    }

    async runBacktest(symbol, tf, cfg) {
      const res = await fetch(cfg.pythonApi + '/backtest/run', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol, tf, ...cfg })
      });
      const r = await res.json();
      if (res.ok && r && (r.ok || r.error)) return r;
      throw new NBXError('HTTP', 'backtest failed', { status: res.status, r });
    }

    async runGridSearch(symbol, tf, grid) {
      const res = await fetch(cfg.pythonApi + '/backtest/grid', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol, tf, grid: grid || undefined })
      });
      const r = await res.json();
      if (res.ok && r && (r.ok || r.error)) return r;
      throw new NBXError('HTTP', 'grid failed', { status: res.status, r });
    }

    async runGridMulti(symbols, tf, grid) {
      const res = await fetch(cfg.pythonApi + '/grid-multi', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbols, tf, grid: grid || undefined })
      });
      const r = await res.json();
      if (res.ok && r && (r.ok || r.error)) return r;
      throw new NBXError('HTTP', 'grid-multi failed', { status: res.status, r });
    }

    async getBacktestQuick(symbol, tf) {
      const r = await this.get(cfg.pythonApi + '/backtest/quick?symbol=' + encodeURIComponent(symbol) + '&tf=' + encodeURIComponent(tf), 1);
      if (r && r.ok) return r;
      throw new NBXError('DATA', 'bad backtest quick');
    }

    async getStats() {
      return this.get('/market/stats');
    }

    async getOrderbook(symbol) {
      return this.get('/v3/orderbook/' + normSymbol(symbol));
    }

    async getOrderbookAll() {
      return this.get('/v3/orderbook/all');
    }

    async getCandles(symbol, timeframe, count) {
      const tfs = { '1m': 60, '5m': 300, '15m': 900, '30m': 1800, '1h': 3600, '4h': 14400, 'D': 86400 };
      const tfSec = tfs[timeframe] || 900;
      const to = Math.floor(Date.now() / 1000);
      const from = to - Math.min(count, 300) * tfSec;
      const res = timeframe === 'D' ? 'D' : tfSec === 3600 ? '60' : tfSec === 240 * 60 ? '240' : tfSec;
      const q = new URLSearchParams({
        symbol: normSymbol(symbol) === 'USDTIRT' ? 'USDTIRT' : normSymbol(symbol),
        resolution: String(res),
        from: String(from),
        to: String(to),
      });
      // Nobitex UDF expects resolution in minutes for intraday, 'D' for daily
      const path = '/market/udf/history?' + q.toString().replace(/resolution=\d+/, 'resolution=' + res);
      const raw = await this.get(path);
      if (!raw || raw.s !== 'ok' || !Array.isArray(raw.c) || raw.c.length === 0) {
        throw new NBXError('DATA', 'bad candles payload for ' + symbol, { raw });
      }
      const rows = raw.t.map((t, i) => ({
        t: t,
        o: +raw.o[i],
        h: +raw.h[i],
        l: +raw.l[i],
        c: +raw.c[i],
        v: +raw.v[i],
      }));
      rows.sort((a, b) => a.t - b.t);
      return rows;
    }
  }
  NBX.NobitexApi = NobitexApi;

  /* ----------------------------------------------------------
   * 3. TA engine (vectorized on array of candles)
   * --------------------------------------------------------- */
  const TA = {};
  const _ema = (arr, len) => {
    const k = 2 / (len + 1);
    let e = arr[0];
    const out = new Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
      e = i === 0 ? arr[0] : arr[i] * k + e * (1 - k);
      out[i] = e;
    }
    return out;
  };
  const _rma = (arr, len) => {
    let s = 0;
    const out = new Array(arr.length);
    for (let i = 0; i < arr.length; i++) {
      s = i < len ? (i === 0 ? arr[0] : (s * (i - 1) + arr[i]) / i) : (s * (len - 1) + arr[i]) / len;
      out[i] = s;
    }
    return out;
  };

  TA.ema = (closes, len) => _ema(closes, len);
  TA.sma = (closes, len) => {
    const out = new Array(closes.length);
    let sum = 0;
    for (let i = 0; i < closes.length; i++) {
      sum += closes[i];
      if (i >= len) sum -= closes[i - len];
      out[i] = i >= len - 1 ? sum / len : null;
    }
    return out;
  };
  TA.rsi = (closes, len) => {
    const gains = [0], losses = [0];
    for (let i = 1; i < closes.length; i++) {
      const d = closes[i] - closes[i - 1];
      gains.push(d > 0 ? d : 0);
      losses.push(d < 0 ? -d : 0);
    }
    const gE = _rma(gains, len), lE = _rma(losses, len);
    return closes.map((_, i) => {
      if (i < len) return null;
      const rs = lE[i] === 0 ? 100 : gE[i] / lE[i];
      return 100 - 100 / (1 + rs);
    });
  };
  TA.macd = (closes, f = 12, s = 26, sig = 9) => {
    const eF = _ema(closes, f), eS = _ema(closes, s);
    const macd = closes.map((_, i) => eF[i] - eS[i]);
    const signal = _ema(macd, sig);
    const hist = macd.map((v, i) => v - signal[i]);
    return { macd, signal, hist };
  };
  TA.tr = (candles) => {
    const out = [0];
    for (let i = 1; i < candles.length; i++) {
      const c = candles[i], pc = candles[i - 1].c;
      out.push(Math.max(c.h - c.l, Math.abs(c.h - pc), Math.abs(c.l - pc)));
    }
    return out;
  };
  TA.atr = (candles, len = 14) => _rma(TA.tr(candles), len);
  TA.bollinger = (closes, len = 20, mult = 2) => {
    const mid = TA.sma(closes, len);
    const sd = closes.map((_, i) => {
      if (i < len - 1 || mid[i] === null) return null;
      let s = 0;
      for (let j = i - len + 1; j <= i; j++) s += (closes[j] - mid[i]) ** 2;
      return Math.sqrt(s / len);
    });
    return closes.map((_, i) => {
      if (mid[i] === null || sd[i] === null) return { mid: null, up: null, low: null, pctB: null };
      const up = mid[i] + mult * sd[i], low = mid[i] - mult * sd[i];
      return { mid: mid[i], up, low, pctB: (closes[i] - low) / (up - low) };
    });
  };
  TA.di_adx = (candles, len = 14) => {
    const tr = TA.tr(candles);
    const pDM = [0], nDM = [0];
    for (let i = 1; i < candles.length; i++) {
      const up = candles[i].h - candles[i - 1].h;
      const dn = candles[i - 1].l - candles[i].l;
      pDM.push(up > dn && up > 0 ? up : 0);
      nDM.push(dn > up && dn > 0 ? dn : 0);
    }
    const trS = _rma(tr, len), pS = _rma(pDM, len), nS = _rma(nDM, len);
    const pdi = candles.map((_, i) => (trS[i] ? (pS[i] / trS[i]) * 100 : 0));
    const ndi = candles.map((_, i) => (trS[i] ? (nS[i] / trS[i]) * 100 : 0));
    const dx = candles.map((_, i) => {
      const sum = pdi[i] + ndi[i];
      return sum ? (Math.abs(pdi[i] - ndi[i]) / sum) * 100 : 0;
    });
    const adx = _rma(dx, len);
    return { pdi, ndi, adx };
  };

  const percentile = (arr, p) => {
    if (!arr.length) return null;
    const s = arr.slice().sort((a, b) => a - b);
    const i = (p / 100) * (s.length - 1);
    const lo = Math.floor(i), hi = Math.ceil(i);
    return lo === hi ? s[lo] : s[lo] + (s[hi] - s[lo]) * (i - lo);
  };
  TA.percentile = percentile;

  /* Composite TA score per symbol (ADR-0005) */
  TA.signalScore = function (candles) {
    if (!candles || candles.length < 60) {
      return { score: 0, direction: 'NEUTRAL', components: {}, reason: 'insufficient data' };
    }
    const closes = candles.map((x) => x.c);
    const vols = candles.map((x) => x.v || 0);
    const n = closes.length;
    const [e9, e21, e50, e200] = [TA.ema(closes, 9), TA.ema(closes, 21), TA.ema(closes, 50), TA.ema(closes, 200)];
    const rsi = TA.rsi(closes, 14);
    const macd = TA.macd(closes);
    const atr = TA.atr(candles, 14);
    const bb = TA.bollinger(closes, 20, 2);
    const di = TA.di_adx(candles, 14);
    const i = n - 1;

    const comp = {};
    // Trend stack score (40%)
    let trend = 0;
    if (closes[i] > e21[i]) trend += 20;
    if (e9[i] > e21[i]) trend += 20;
    if (e21[i] > e50[i]) trend += 25;
    if (closes[i] > (e200[i] || closes[i])) trend += 15;
    if (di.adx[i] && di.adx[i] > 22 && di.pdi[i] > di.ndi[i]) trend += 20;
    comp.trend = clamp(trend, 0, 100);

    // Momentum (25%)
    let mom = 50;
    const r = rsi[i], h = macd.hist;
    if (r !== null) {
      if (r > 55 && r < 72) mom += 20;
      else if (r < 45) mom -= 15;
      else if (r >= 72) mom += 5;
    }
    if (h[i] > h[i - 1] && h[i] > 0) mom += 25;
    else if (h[i] < h[i - 1] && h[i] < 0) mom -= 10;
    comp.momentum = clamp(mom, 0, 100);

    // Volume (15%)
    let vol = 50;
    const vAvg = vols.slice(-30, -1).reduce((a, b) => a + b, 0) / Math.max(vols.slice(-30, -1).length, 1);
    const vNow = vols[i];
    if (vNow > vAvg * 1.4) vol += 30;
    else if (vNow < vAvg * 0.6) vol -= 15;
    if (closes[i] > closes[i - 1] && vNow > vAvg) vol += 10;
    comp.volume = clamp(vol, 0, 100);

    // Structure/Bollinger %b (20%)
    let strc = 50;
    const bbNow = bb[i];
    if (bbNow.pctB !== null) {
      if (bbNow.pctB > 0.7) strc += 25;
      else if (bbNow.pctB < 0.25) strc -= 15;
    }
    if (closes[i] > Math.max(...closes.slice(-20, -1))) strc += 10;
    comp.structure = clamp(strc, 0, 100);

    // Regime gating via ADX
    const regime = di.adx[i] > 25 ? 'TREND' : 'RANGE';
    const gating = regime === 'TREND' ? 1 : 0.85;
    const raw =
      0.4 * comp.trend + 0.25 * comp.momentum + 0.15 * comp.volume + 0.2 * comp.structure;
    const score = clamp(raw * gating, 0, 100);

    const direction = score >= 68 ? 'LONG' : score >= 55 ? 'NEUTRAL' : 'EXIT';
    const stopDist = atr[i] * 2;
    return {
      score: +score.toFixed(1),
      direction,
      regime,
      components: {
        trend: comp.trend,
        momentum: comp.momentum,
        volume: comp.volume,
        structure: comp.structure,
      },
      risk: {
        atr: atr[i],
        stopDistance: stopDist,
        stopPct: (stopDist / closes[i]) * 100,
      },
      diagnostics: {
        rsi: r, adx: di.adx[i], pctB: bbNow.pctB, macdHist: h[i], e9: e9[i], e21: e21[i], e50: e50[i],
      },
      lastClose: closes[i],
    };
  };
  NBX.TA = TA;

  /* ----------------------------------------------------------
   * 4. Market store + scanner (ADR-0004/0007)
   * --------------------------------------------------------- */
  class MarketEngine {
    constructor(api) {
      this.api = api;
      this.universe = [];       // [{symbol, last, vol24, change24}]
      this.books = {};          // symbol -> {bestBid,bestAsk,spreadPct}
      this.candles = {};        // symbol -> per tf rows
      this.signals = {};        // symbol -> per tf signal object
      this.premium = null;      // USDTIRT last
      this.onUpdate = [];
      this.scanning = false;
    }
    subscribe(fn) { this.onUpdate.push(fn); return () => (this.onUpdate = this.onUpdate.filter((x) => x !== fn)); }
    emit(type, payload) { this.onUpdate.forEach((f) => { try { f(type, payload); } catch (e) {} }); }

    async loadUniverse() {
      try {
        const stats = await this.api.getStats();
        if (stats && stats.stats) {
          const rows = Object.entries(stats.stats).map(([sym, d]) => ({
            symbol: normSymbol(sym),
            last: +d.latest || +d.last || 0,
            vol24: +d.valueDst || +d.volumeDst || +d['24h_volume'] || 0,
            change24: +d.dayChange || 0,
          }));
          this.universe = rows.filter((r) => r.symbol && r.last > 0);
          this.premium = (rows.find((x) => x.symbol === 'USDTIRT') || {}).last || null;
        }
      } catch (e) {
        this.universe = cfg.seedSymbols.map((s, i) => ({
          symbol: s, last: 0, vol24: 100000 - i * 1000, change24: 0,
        }));
      }
      this.universe = this.universe
        .sort((a, b) => b.vol24 - a.vol24)
        .slice(0, cfg.universeTopN);
      this.emit('universe', this.universe);
    }

    async scan(timeframe) {
      if (this.scanning) return;
      this.scanning = true;
      const tf = timeframe || cfg.timeframes[0];
      const tasks = this.universe.map((u) => async () => {
        const sym = u.symbol;
        try {
          const rows = await this.api.getCandles(sym, tf, cfg.maxCandles);
          this.candles[sym] = rows;
          this.signals[sym] = NBX.TA.signalScore(rows);
        } catch (e) {
          // fallback: synthesize candles for demo-mode UI consistency
          this.candles[sym] = this._synthCandles(u.last || 1000);
          this.signals[sym] = NBX.TA.signalScore(this.candles[sym]);
        }
      });
      // throttled concurrency 6
      const q = tasks.slice();
      const workers = new Array(6).fill(0).map(async () => {
        while (q.length) {
          const job = q.shift();
          if (job) await job();
        }
      });
      await Promise.all(workers);
      this.scanning = false;
      this.emit('signals', this.rankSignals());
    }

    _synthCandles(base) {
      const rows = [];
      let v = base * (0.8 + Math.random() * 0.4);
      const now = Math.floor(Date.now() / 1000);
      for (let i = cfg.maxCandles; i >= 1; i--) {
        const o = v;
        v = v * (1 + (Math.random() - 0.48) * 0.012);
        rows.push({ t: now - i * 900, o, h: Math.max(o, v) * 1.002, l: Math.min(o, v) * 0.998, c: v, v: Math.random() * 10 });
      }
      this.candles = this.candles; // no-op for clarity
      return rows;
    }

    rankSignals() {
      return this.universe
        .map((u) => {
          const s = this.signals[u.symbol] || { score: 0, direction: 'NEUTRAL' };
          const liq = clamp(50 + Math.log10(u.vol24 + 1) * 4, 0, 100);
          const fa = 50; // stub: FA layer joins later per ADR-0006
          const composite = clamp(0.55 * s.score + 0.25 * fa + 0.2 * liq, 0, 100);
          return { ...u, ...s, liquidity_score: liq | 0, fa_score: fa, composite: +composite.toFixed(1) };
        })
        .sort((a, b) => b.composite - a.composite);
    }
  }
  NBX.MarketEngine = MarketEngine;

  /* ----------------------------------------------------------
   * 5. Facade helpers
   * --------------------------------------------------------- */
  NBX.createCore = function (overrides) {
    const api = new NobitexApi(overrides);
    const engine = new MarketEngine(api);
    return { api, engine };
  };

  NBX.state = { ready: false };
  NBX.boot = async function () {
    if (NBX.state.ready) return NBX.core;
    const core = NBX.createCore();
    NBX.core = core;
    await core.engine.loadUniverse();
    await core.engine.scan(cfg.timeframes[0]);
    NBX.state.ready = true;
    return core;
  };
})();
