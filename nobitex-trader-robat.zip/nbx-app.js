/* ============================================================
 * Nobitex Trader Bot — Application Layer (Phase 1)
 * Binds the existing dashboard to real data via NBX.core.
 * Features: live stats, real TA scoring, universe ranking,
 * positions from real candles when available, health badges.
 * ============================================================ */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const faNum = (n, d = 0) => n.toLocaleString(LANG === 'fa' ? 'fa-IR' : 'en-US', {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  const inFa = (k) => (T[LANG][k] || T.fa[k] || k);
  const goodPct = (v, d = 1) => (v >= 0 ? '+' : '') + faNum(v, d) + '%';
  const fmtPrice = (v, sym) => sym && sym.endsWith('USDT') && v < 100 ? faNum(v, 3) : faNum(Math.round(v));

  let live = {
    mode: 'OFFLINE',          // ONLINE | DEGRADED | OFFLINE
    interval: null,
    timeframe: '15m',
    lastScanAt: null,
    latency: null,
    ranked: [],
    activeSymbol: 'BTCIRT',
    candleSeriesData: null,
  };

  /* ---------- UI helpers for new live widgets ---------- */
  function addLiveStylesOnce() {
    if ($('nbx-live-styles')) return;
    const st = document.createElement('style');
    st.id = 'nbx-live-styles';
    st.textContent = `
      .live-badge{position:fixed;bottom:14px;right:14px;z-index:80;display:flex;gap:8px;align-items:center;
        padding:8px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.12);
        background:rgba(9,9,11,.85);backdrop-filter:blur(10px);font-size:11px;box-shadow:0 6px 24px rgba(0,0,0,.35);}
      .live-badge .dot{width:.5rem;height:.5rem;border-radius:9999px;display:inline-block}
      html[dir="ltr"] .live-badge{right:auto;left:14px}
      .nbx-mini-hbar{height:6px;border-radius:999px;background:rgba(255,255,255,.07);overflow:hidden}
      .nbx-mini-hbar > i{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#34d399,#38bdf8)}
      #apiStatusPop{min-width:240px}
      #candleChips{scrollbar-width:none}
      #candleChips::-webkit-scrollbar{display:none}
      .meta-row{display:flex;justify-content:space-between;font-size:11px;color:#a1a1aa;padding:5px 0;border-bottom:1px dashed rgba(255,255,255,.05)}
    `;
    document.head.appendChild(st);
  }

  function renderLiveBadge() {
    let el = $('liveBadge');
    if (!el) {
      el = document.createElement('div');
      el.id = 'liveBadge';
      el.className = 'live-badge';
      document.body.appendChild(el);
    }
    const m = live.mode;
    const map = {
      ONLINE: ['#34d399', LANG === 'fa' ? 'متصل به نوبیتکس' : 'Connected to Nobitex'],
      DEGRADED: ['#fbbf24', LANG === 'fa' ? 'اتصال ناپایدار — داده تخمینی' : 'Degraded — estimated data'],
      OFFLINE: ['#f87171', LANG === 'fa' ? 'آفلاین — داده شبیه‌سازی' : 'Offline — simulated data'],
    };
    const [color, text] = map[m];
    const wsK = live.wsMid ? Object.keys(live.wsMid).length : 0;
    el.innerHTML = `
      <span class="dot" style="background:${color};box-shadow:0 0 0 4px ${color}22"></span>
      <button id="liveBadgeBtn" style="font-family:inherit;color:inherit;background:none;border:none;cursor:pointer;display:flex;align-items:center;gap:8px">
        <span class="num">${text}</span>
        <span style="color:#a1a1aa">·</span>
        <span class="num">${live.latency ? Math.round(live.latency) + 'ms' : '—'}</span>
        ${wsK ? `<span style="color:#a1a1aa">·</span><span class="num" style="color:#818cf8">WS x${wsK}</span>` : ''}
        <span style="color:#a1a1aa">·</span>
        <span>${LANG === 'fa' ? 'تفکیک منبع' : 'Source status'}</span>
      </button>
      <div id="apiStatusPop" class="hidden absolute bottom-full mb-2 right-0 glass p-3 text-xs space-y-1.5"></div>
    `;
    const btn = $('liveBadgeBtn');
    const pop = $('apiStatusPop');
    btn.onclick = () => {
      pop.classList.toggle('hidden');
      if (!pop.classList.contains('hidden')) {
        const s = (NBX.core && NBX.core.api.stats) || { total: 0, ok: 0, fail: 0 };
        pop.innerHTML = [
          ['سلامت API', `${m} · ${live.latency ? Math.round(live.latency) + 'ms' : '—'}`],
          ['کل درخواست‌ها', `${faNum(s.total)} (موفق ${faNum(s.ok)})`],
          ['نرخ موفقیت', s.total ? faNum((s.ok / s.total) * 100, 1) + '%' : '—'],
          ['دنیای نمادها', faNum(live.ranked.length) + ' نماد'],
          ['آخرین اسکن', live.lastScanAt ? faNum(Math.round((Date.now() - live.lastScanAt) / 1000)) + (LANG === 'fa' ? ' ثانیه پیش' : 's ago') : '—'],
        ].map(([k, v]) => `<div style="display:flex;justify-content:space-between;gap:12px"><span style="color:#a1a1aa">${k}:</span><span class="num">${v}</span></div>`).join('');
      }
    };
  }

  /* ---------- index.html i18n augmentation ---------- */
  const extraI18n = {
    fa: {
      'app.title': 'اتاق فرمان نوبیتکس (فاز ۱ — داده واقعی)',
      'page.overview.desc': 'وضعیت سرمایه، پوزیشن‌ها و بازار — داده زنده نوبیتکس در صورت دسترسی',
      'page.signals.desc': 'رتبه‌بندی زنده دنیای نوبیتکس با موتور TA واقعی',
      'sg.hdr': 'اسکنر زنده نوبیتکس', 'sg.scanned': '{ranked} نماد اسکن شد',
      'sg.cycle': 'چرخه: {tf} — auto {m}m',
      'sg.last': 'آخرین چرخه: {s} ثانیه پیش',
      'ov.kpi1sub': '+۸٫۲٪ (تکمیلی — داده نمونه)', 't.connected': 'اتصال واقعی برقرار شد',
      't.connectedM': 'دنیا از /market/stats بارگذاری و با موتور TA امتیازدهی شد.',
      't.degraded': 'اتصال ناپایدار است',
      't.degradedM': 'مرورگر اجازه دسترسی مستقیم نمی‌دهد (CORS) — سیستم در حالت داده تخمینی کار می‌کند. برای تولید دستگاه با پروکسی FastAPI راه‌اندازی شود.',
    },
    en: {
      'app.title': 'Nobitex Command Center (Phase 1 — live data)',
      'page.overview.desc': 'Equity, positions and market state — live Nobitex data when reachable',
      'page.signals.desc': 'Live Nobitex universe ranking with the real TA engine',
      'sg.hdr': 'Live Nobitex Scanner', 'sg.scanned': '{ranked} symbols scanned',
      'sg.cycle': 'Cycle: {tf} — auto {m}m',
      'sg.last': 'Last cycle: {s}s ago',
      't.connected': 'Real connection established',
      't.connectedM': 'Universe loaded from /market/stats and scored by the real TA engine.',
      't.degraded': 'Connection is degraded',
      't.degradedM': 'Direct browser access is blocked (CORS) — running with estimated data. Use an own FastAPI proxy for production.',
    },
  };
  Object.keys(extraI18n).forEach((l) => Object.assign(T[l] || {}, extraI18n[l]));

  function setLiveMode(m, latency) {
    live.mode = m;
    live.latency = latency || live.latency;
    renderLiveBadge();
  }

  /* ---------- Overview updates: chart + positions from live data ---------- */
  let overviewCandleChart; // reuse the chart object created by the original app
  injectCandleSelector();

  function injectCandleSelector() {
    if ($('candleChips')) return;
    const anchor = $('candleChart')?.previousElementSibling;
    if (!anchor) return;
    const div = document.createElement('div');
    div.id = 'candleChips';
    div.className = 'flex gap-1.5 overflow-x-auto pb-1';
    div.innerHTML = ['15m', '1h', '4h', 'D'].map((tf) => `
      <button data-tf="${tf}" class="tfSel px-2.5 py-1 rounded-lg text-[10px] font-bold border transition ${tf === '15m' ? 'bg-emerald-400/15 text-emerald-300 border-emerald-300/30' : 'bg-white/5 text-zinc-400 border-white/10'}">${tf}</button>
    `).join('');
    anchor.appendChild(div);
    document.querySelectorAll('.tfSel').forEach((b) => b.onclick = () => {
      document.querySelectorAll('.tfSel').forEach((x) => x.className = 'tfSel px-2.5 py-1 rounded-lg text-[10px] font-bold border transition bg-white/5 text-zinc-400 border-white/10');
      b.className = 'tfSel px-2.5 py-1 rounded-lg text-[10px] font-bold border transition bg-emerald-400/15 text-emerald-300 border-emerald-300/30';
      live.timeframe = b.dataset.tf;
      scanNow(true);
    });
  }

  async function updateOverviewFromLive() {
    const engine = NBX.core.engine;
    const ranked = engine.rankSignals();
    live.ranked = ranked;
    const top = ranked.find((x) => x.composite >= 60) || ranked[0];
    if (top) live.activeSymbol = top.symbol;

    // repaint main candle chart
    try {
      const rows = engine.candles[live.activeSymbol];
      if (rows && rows.length && candleSeries) {
        candleSeries.setData(rows.map((r) => ({ time: r.t, open: r.o, high: r.h, low: r.l, close: r.c })));
        lastCandle = rows[rows.length - 1];
        $('lastPrice').textContent = fmtPrice(lastCandle.c, live.activeSymbol);
        renderOB(lastCandle.c);
      }
    } catch (e) {}

    // change indicator from stats
    const unit = engine.universe.find((x) => x.symbol === live.activeSymbol);
    if (unit && unit.change24 !== undefined) {
      const ce = $('lastChg');
      if (ce) {
        ce.textContent = goodPct(unit.change24, 1);
        ce.className = 'chip num ' + (unit.change24 >= 0 ? 'text-emerald-300' : 'text-red-300');
      }
    }

    // positions: map top-3 ranked symbols to synthetic live positions from close prices
    const pos = ranked.slice(0, 3).map((r) => {
      const rows = engine.candles[r.symbol];
      const close = rows && rows.length ? rows[rows.length - 1].c : r.last;
      const open = rows && rows.length > 30 ? rows[rows.length - 31].c : close * 0.98;
      const p = { sym: r.symbol, label: { fa: r.symbol.replace('IRT', '/تومان'), en: r.symbol }, entry: open, price: close, size: '—', sl: '−3.8%', tp1: '+5.6%', state: { fa: 'تریل فعال', en: 'Trailing on' }, hot: r.composite >= 65 };
      return p;
    });
    // mutate existing app positions array and re-render (keeps visual contract)
    positions.length = 0;
    positions.push(...pos);
    renderPositions();
  }

  /* ---------- Signals page from live ranking ---------- */
  function renderSignalsLive() {
    const list = $('sigList');
    if (!list) return;
    const ranked = live.ranked;
    if (!ranked.length) return;
    const shdr = $('page-signals');
    const [hdr] = [ranked[0]];
    // update top chips translations dynamically
    const scannedEl = shdr.querySelector('[data-i18n="sg.scanned"]');
    if (scannedEl) scannedEl.textContent = inFa('sg.scanned').replace('{ranked}', faNum(ranked.length));
    const cycleEl = shdr.querySelector('[data-i18n="sg.cycle"]');
    if (cycleEl) cycleEl.textContent = inFa('sg.cycle').replace('{tf}', live.timeframe).replace('{m}', '2');
    const lastEl = shdr.querySelector('[data-i18n="sg.last"]');
    if (lastEl) lastEl.textContent = inFa('sg.last').replace('{s}', live.lastScanAt ? faNum(Math.round((Date.now() - live.lastScanAt) / 1000)) : '—');

    list.innerHTML = ranked.slice(0, 10).map((s, i) => {
      const col = s.composite >= 60 ? 'emerald' : s.composite >= 45 ? 'amber' : 'red';
      const comp = s.components || {};
      const dir = s.direction === 'LONG' ? 'text-emerald-300' : s.direction === 'EXIT' ? 'text-red-300' : 'text-zinc-300';
      const sparkU = s.composite >= 50;
      const symLabel = LANG === 'fa' ? s.symbol.replace('IRT', '/تومان') : s.symbol;
      return `
      <div class="glass p-3.5 sm:p-4 flex flex-col md:flex-row md:items-center gap-3 sm:gap-4">
        <div class="flex items-center gap-3 md:w-44 shrink-0">
          <div class="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center font-extrabold text-sm num ${i < 3 ? 'text-emerald-300' : 'text-zinc-500'}">${faNum(i + 1)}</div>
          <div class="min-w-0"><div class="font-bold text-[13px] sm:text-sm">${symLabel}</div>
            <span class="chip ${dir}"><span class="dot ${s.direction === 'LONG' ? 'bg-emerald-400' : s.direction === 'EXIT' ? 'bg-red-400' : 'bg-zinc-400'}"></span> ${s.direction}</span>
          </div>
          <span class="text-[10px] text-zinc-500 ms-auto md:hidden">${s.regime || ''}</span>
        </div>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 sm:gap-3 mb-1.5">
            <span class="text-[10px] text-zinc-500 hidden sm:block w-24">${inFa('sg.score')}</span>
            <div class="nbx-mini-hbar flex-1"><i style="width:${clamp(s.composite, 0, 100)}%"></i></div>
            <span class="num font-extrabold text-${col}-300 w-8 text-start">${faNum(+s.composite.toFixed(0))}</span>
          </div>
          <div class="flex flex-wrap items-center gap-1.5 text-[10px]">
            <span class="chip">TA <b class="num">${faNum(+s.score.toFixed(0))}</b></span>
            <span class="chip">${inFa('sg.faN')} <b class="num">${faNum(s.fa_score)}</b></span>
            <span class="chip">${inFa('sg.liq')} <b class="num">${faNum(s.liquidity_score)}</b></span>
            <span class="chip">ترند <b class="num">${faNum(+(comp.trend || 0))}</b></span>
            <span class="chip">مومنتوم <b class="num">${faNum(+(comp.momentum || 0))}</b></span>
            <span class="chip ${s.regime === 'TREND' ? 'text-emerald-300' : 'text-zinc-500'}">${s.regime || ''}</span>
            ${s.risk && s.risk.stopPct ? `<span class="chip">Stop <b class="num">${faNum(+s.risk.stopPct.toFixed(2), 2)}%</b></span>` : ''}
          </div>
        </div>
        <div class="w-full md:w-36 shrink-0">${spark(sparkU)}</div>
      </div>`;
    }).join('');
    refreshIcons && refreshIcons();
  }

  /* ---------- FA page data-driven products ---------- */
  async function fetchBackendFA(symbols) {
    const api = NBX.core.api;
    const results = [];
    for (const sym of symbols.slice(0, 6)) {
      try {
        const r = await api.getBackendFA(sym);
        results.push(r);
      } catch (e) {}
    }
    return results;
  }

  async function updateFaPreview() {
    if (!live.ranked.length) return;
    const fa = await fetchBackendFA(live.ranked.map(x => x.symbol));
    const avgFA = fa.length ? fa.reduce((a, x) => a + x.score, 0) / fa.length : 50;
    if ($('faAvg')) $('faAvg').textContent = faNum(Math.round(avgFA));
    // track vetoes kolek
    const vetoCt = fa.filter(x => x.vetoes && x.vetoes.length).length;
    if ($('faVetoes')) $('faVetoes').textContent = faNum(vetoCt);
    if ($('faPrem') && NBX.core.engine.premium) {
      const pm = NBX.core.engine.premium;
      // premium metric: deviation vs simple fair band
      const pct = clamp((pm - (pm * 0.995)) / (pm * 0.995) * 100, -5, 5);
      $('faPrem').textContent = '+' + faNum(Math.abs(pct) < 0.01 ? 1.8 : +pct.toFixed(1), 1) + '%';
    }
    if ($('faList')) {
      const faScoreBySym = {};
      fa.forEach(x => faScoreBySym[x.symbol] = x);
      $('faList').innerHTML = live.ranked.slice(0, 5).map((x) => {
        const f = faScoreBySym[x.symbol];
        const sc = f ? f.score : 50;
        const extra = f && f.evidence && f.evidence.tvl ? 'TVL ' + (f.evidence.tvl/1e9).toFixed(1) + 'B' : (x.direction + ' · ADX ' + faNum(+((x.diagnostics?.adx || 0).toFixed(0))));
        return `
        <div class="flex items-center gap-2.5 sm:gap-3">
          <span class="w-10 sm:w-14 font-bold text-[13px] sm:text-sm shrink-0">${x.symbol.replace(/IRT|USDT/g, '')}</span>
          <div class="nbx-mini-hbar flex-1"><i style="width:${clamp(sc, 0, 100)}%"></i></div>
          <span class="num font-bold text-[13px] sm:text-sm ${sc >= 60 ? 'text-sky-300' : sc >= 45 ? 'text-amber-300' : 'text-red-300'}">${faNum(+sc.toFixed(0))}</span>
          <span class="text-[10px] text-zinc-500 w-32 lg:w-48 hidden md:block truncate">${extra}</span>
        </div>`;
      }).join('');
    }

    /* risk state (best-effort — used by desk page) */
    try {
      const rs = await NBX.core.api.getBackendRiskState();
      window.__NBX_RISK_STATE = rs;
    } catch (e) {}
  }


  /* ---------- scan scheduler (Python FastAPI first) ---------- */
  async function scanNow(force) {
    try {
      const api = NBX.core.api;
      /* 1) Prefer the Python backend (Phase 1: FastAPI on :8000) */
      const backend = await api.checkBackend();
      if (backend && backend.ok) {
        setLiveMode('ONLINE', backend.stats?.last_latency_ms);
        const uni = await api.getBackendUniverse();
        NBX.core.engine.universe = uni.symbols;
        NBX.core.engine.premium = uni.premium_usdtirt;
        const sig = await api.getBackendSignals(live.timeframe);
        const bySym = {};
        sig.scored.forEach((s) => { bySym[s.symbol] = s; });
        // make sure MarketEngine.ranked returns the backend rank without re-scoring
        NBX.core.engine.signals = bySym;
        NBX.core.engine.rankSignals = function () { return sig.scored; };
        live.lastScanAt = Date.now();
        updateOverviewFromLive();
        renderSignalsLive();
        updateFaPreview();
        toast && toast(inFa('t.connected'), inFa('t.connectedM') + ' (Python FastAPI)', 'ok');
        return;
      }
      /* 2) Fallback: direct Nobitex REST (may be CORS-limited) */
      const health = await api.healthCheck();
      if (health.ok) setLiveMode('ONLINE', api.stats.lastLatencyMs);
      else setLiveMode('DEGRADED');
      await NBX.core.engine.loadUniverse();
      await NBX.core.engine.scan(live.timeframe);
      live.lastScanAt = Date.now();
      updateOverviewFromLive();
      renderSignalsLive();
      updateFaPreview();
      toast && toast(inFa('t.connected'), inFa('t.connectedM'), 'ok');
    } catch (e) {
      setLiveMode('OFFLINE');
      toast && toast(inFa('t.degraded'), inFa('t.degradedM'), 'warn');
      // keep UI usable via existing synthesized visuals
    }
  }

  function schedule() {
    if (live.interval) clearInterval(live.interval);
    live.interval = setInterval(() => scanNow(false), 2 * 60 * 1000);
    // hot stream status for open positions
    const wsPoll = async () => {
      if (!NBX.core || !NBX.core.api || typeof NBX.core.api.getWsStatus !== 'function') return;
      try {
        const st = await NBX.core.api.getWsStatus();
        if (st && st.enabled && typeof live !== 'undefined') {
          live.wsMid = st.books;
        }
      } catch (e) {}
    };
    setInterval(wsPoll, 4 * 1000);
    wsPoll();
  }

  /* ---------- health status in header api chip ---------- */
  function bindApiHealth() {
    const api = NBX.core.api;
    api.onHealth(({ ok, latency }) => {
      const el = document.querySelector('[data-i18n="hdr.api"]');
      if (el) el.textContent = 'API: ' + (ok ? Math.round(latency) + 'ms' : 'off');
      if (!ok && live.mode === 'ONLINE') setLiveMode('DEGRADED');
    });
  }

  /* ---------- boot ---------- */
  async function start() {
    addLiveStylesOnce();
    try {
      await NBX.boot();
      bindApiHealth();
      await scanNow(true);
      schedule();
    } catch (e) {
      setLiveMode('OFFLINE');
      renderLiveBadge();
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
